import { NextResponse } from 'next/server';
import { getServerAuthUser } from '@/lib/auth/jwt';
import { getUserById } from '@/lib/db/users';
import { getFlightsByUserId } from '@/lib/db/flights';
import { getEcreditRequestsByUserId } from '@/lib/db/ecredit-requests';

// This endpoint provides dashboard statistics for the current user
export async function GET(request: Request) {
  try {
    // Get authenticated user
    const authUser = await getServerAuthUser();
    if (!authUser) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    // Get user details
    const user = await getUserById(authUser.userId);
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'User not found' },
        { status: 404 }
      );
    }
    
    // Get user's flights
    const flights = await getFlightsByUserId(user.id, false); // false = include inactive
    
    // Get user's ecredit requests
    const ecreditRequests = await getEcreditRequestsByUserId(user.id);
    
    // Calculate statistics
    const totalFlights = flights.length;
    const activeFlights = flights.filter(flight => flight.active).length;
    
    // Count flights with price drops (flights that have ecredit requests)
    const flightIdsWithEcreditRequests = new Set(ecreditRequests.map(request => request.flightId));
    const flightsWithPriceDrops = flightIdsWithEcreditRequests.size;
    
    // Calculate total savings from completed ecredit requests
    const totalSavings = ecreditRequests
      .filter(request => request.status === 'completed')
      .reduce((sum, request) => sum + (request.ecreditAmount || 0), 0);
    
    // Count pending and completed ecredit requests
    const pendingEcreditRequests = ecreditRequests.filter(request => 
      request.status === 'pending' || request.status === 'in_progress'
    ).length;
    
    const completedEcreditRequests = ecreditRequests.filter(request => 
      request.status === 'completed'
    ).length;
    
    // Count upcoming flights (departure date in the future)
    const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
    const upcomingFlights = flights.filter(flight => 
      flight.active && flight.departureDate >= today
    ).length;
    
    return NextResponse.json({
      success: true,
      stats: {
        totalFlights,
        activeFlights,
        flightsWithPriceDrops,
        totalSavings,
        pendingEcreditRequests,
        completedEcreditRequests,
        upcomingFlights
      }
    });
  } catch (error) {
    console.error('Error getting dashboard stats:', error);
    return NextResponse.json(
      { success: false, message: 'Failed to get dashboard stats' },
      { status: 500 }
    );
  }
}
