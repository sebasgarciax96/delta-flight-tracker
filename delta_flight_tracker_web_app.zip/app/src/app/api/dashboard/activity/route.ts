import { NextResponse } from 'next/server';
import { getServerAuthUser } from '@/lib/auth/jwt';
import { getUserById } from '@/lib/db/users';
import { getNotificationsByUserId } from '@/lib/db/notifications';

// This endpoint provides recent activity for the dashboard
export async function GET(request: Request) {
  try {
    // Get authenticated user
    const authUser = await getServerAuthUser();
    if (!authUser) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    // Get user details
    const user = await getUserById(authUser.userId);
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'User not found' },
        { status: 404 }
      );
    }
    
    // Get recent notifications as activity
    const notifications = await getNotificationsByUserId(user.id, 10, 0); // Limit to 10 most recent
    
    // Format notifications as activity items
    const activity = notifications.map(notification => ({
      id: notification.id,
      type: notification.type,
      title: notification.title,
      message: notification.message,
      date: notification.createdAt
    }));
    
    return NextResponse.json({
      success: true,
      activity
    });
  } catch (error) {
    console.error('Error getting dashboard activity:', error);
    return NextResponse.json(
      { success: false, message: 'Failed to get dashboard activity' },
      { status: 500 }
    );
  }
}
