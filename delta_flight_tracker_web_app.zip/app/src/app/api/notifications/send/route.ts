import { NextResponse } from 'next/server';
import { getServerAuthUser } from '@/lib/auth/jwt';
import { sendEmail } from '@/lib/notifications/email-service';
import { sendSMS } from '@/lib/notifications/sms-service';
import { getUserById } from '@/lib/db/users';
import { getFlightById } from '@/lib/db/flights';
import { getNotificationById, markNotificationAsRead } from '@/lib/db/notifications';

// This endpoint handles sending notifications to users
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { notificationId, sendMethod } = body;
    
    if (!notificationId) {
      return NextResponse.json(
        { success: false, message: 'Notification ID is required' },
        { status: 400 }
      );
    }
    
    // Get notification details
    const notification = await getNotificationById(notificationId);
    if (!notification) {
      return NextResponse.json(
        { success: false, message: 'Notification not found' },
        { status: 404 }
      );
    }
    
    // Get user details
    const user = await getUserById(notification.userId);
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'User not found' },
        { status: 404 }
      );
    }
    
    // Determine notification method
    const method = sendMethod || user.notificationPreference || 'email';
    
    // Send notification based on method
    let success = false;
    if (method === 'email') {
      success = await sendEmail({
        to: user.email,
        subject: notification.title,
        text: notification.message,
        html: `<h1>${notification.title}</h1><p>${notification.message}</p>`
      });
    } else if (method === 'sms' && user.phoneNumber) {
      success = await sendSMS({
        to: user.phoneNumber,
        message: `${notification.title}: ${notification.message}`
      });
    } else {
      return NextResponse.json(
        { success: false, message: 'Invalid notification method or missing phone number' },
        { status: 400 }
      );
    }
    
    if (success) {
      // Mark notification as read if it was successfully sent
      await markNotificationAsRead(notificationId);
      
      return NextResponse.json({
        success: true,
        message: `Notification sent via ${method}`,
        notificationId
      });
    } else {
      return NextResponse.json(
        { success: false, message: `Failed to send notification via ${method}` },
        { status: 500 }
      );
    }
  } catch (error) {
    console.error('Error sending notification:', error);
    return NextResponse.json(
      { success: false, message: 'Failed to send notification' },
      { status: 500 }
    );
  }
}
