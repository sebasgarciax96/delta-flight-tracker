import { NextResponse } from 'next/server';
import { getServerAuthUser } from '@/lib/auth/jwt';
import { RequestStatus } from '@/lib/db/ecredit-requests';
import { AirlineCommunicator } from '@/lib/airline-communicator/airline-communicator';
import { getPendingEcreditRequests, updateEcreditRequestStatus } from '@/lib/db/ecredit-requests';
import { getFlightById } from '@/lib/db/flights';
import { getUserById } from '@/lib/db/users';
import { createEcreditSuccessNotification } from '@/lib/db/notifications';

// This function will be called by a scheduled task to process pending ecredit requests
export async function GET() {
  try {
    // In a real production environment, this endpoint would be protected
    // and only accessible by authenticated cron jobs or admin users
    
    // Get all pending ecredit requests
    const pendingRequests = await getPendingEcreditRequests();
    
    if (!pendingRequests || pendingRequests.length === 0) {
      return NextResponse.json({ 
        success: true, 
        message: 'No pending ecredit requests to process',
        processedRequests: 0,
        successfulRequests: 0
      });
    }
    
    // Initialize airline communicator
    const airlineCommunicator = new AirlineCommunicator();
    
    // Track statistics
    let processedRequests = 0;
    let successfulRequests = 0;
    
    // Process each pending request
    for (const request of pendingRequests) {
      try {
        // Update request status to in progress
        await updateEcreditRequestStatus(request.id, RequestStatus.IN_PROGRESS);
        
        // Get flight details
        const flight = await getFlightById(request.flightId);
        if (!flight) {
          await updateEcreditRequestStatus(
            request.id, 
            RequestStatus.FAILED,
            { notes: 'Flight not found' }
          );
          continue;
        }
        
        // Get user details
        const user = await getUserById(flight.userId);
        if (!user) {
          await updateEcreditRequestStatus(
            request.id, 
            RequestStatus.FAILED,
            { notes: 'User not found' }
          );
          continue;
        }
        
        // Check if airline is supported
        if (flight.airline.toLowerCase() !== 'delta') {
          await updateEcreditRequestStatus(
            request.id, 
            RequestStatus.FAILED,
            { notes: `Airline ${flight.airline} not supported` }
          );
          continue;
        }
        
        // Process the ecredit request
        const result = await airlineCommunicator.requestEcredit(
          flight.airline,
          user,
          flight,
          request
        );
        
        processedRequests++;
        
        if (result.success) {
          successfulRequests++;
          
          // Update request status to completed
          await updateEcreditRequestStatus(
            request.id, 
            RequestStatus.COMPLETED,
            {
              completionDate: new Date().toISOString(),
              ecreditAmount: result.ecreditAmount,
              ecreditCode: result.ecreditCode,
              ecreditExpirationDate: result.ecreditExpirationDate
            }
          );
          
          // Create notification for user
          await createEcreditSuccessNotification(
            user.id,
            {
              airline: flight.airline,
              flightNumber: flight.flightNumber,
              ecreditAmount: result.ecreditAmount,
              ecreditCode: result.ecreditCode,
              ecreditExpirationDate: result.ecreditExpirationDate
            }
          );
        } else {
          // Update request status to failed
          await updateEcreditRequestStatus(
            request.id, 
            RequestStatus.FAILED,
            { notes: result.error || 'Unknown error' }
          );
        }
      } catch (requestError) {
        console.error(`Error processing ecredit request ${request.id}:`, requestError);
        
        // Update request status to failed
        await updateEcreditRequestStatus(
          request.id, 
          RequestStatus.FAILED,
          { notes: `Error: ${requestError.message || 'Unknown error'}` }
        );
      }
    }
    
    return NextResponse.json({ 
      success: true, 
      message: 'Ecredit request processing completed',
      processedRequests,
      successfulRequests
    });
  } catch (error) {
    console.error('Error in ecredit request processing:', error);
    return NextResponse.json(
      { success: false, message: 'Failed to process ecredit requests' },
      { status: 500 }
    );
  }
}
