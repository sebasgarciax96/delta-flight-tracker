import { NextRequest, NextResponse } from 'next/server';
import { getServerAuthUser } from '@/lib/auth/jwt';

// This file contains the Cloudflare Worker configuration for scheduled tasks

export const config = {
  runtime: 'edge',
};

// This function will be called by Cloudflare cron trigger
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const task = searchParams.get('task');
    
    if (!task) {
      return NextResponse.json(
        { success: false, message: 'Task parameter is required' },
        { status: 400 }
      );
    }
    
    // Check for authorization token for cron jobs
    const authHeader = request.headers.get('authorization');
    const cronSecret = process.env.CRON_SECRET;
    
    if (!cronSecret || !authHeader || !authHeader.startsWith('Bearer ') || authHeader.slice(7) !== cronSecret) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    let result;
    
    // Execute the requested task
    switch (task) {
      case 'check-prices':
        result = await checkPrices();
        break;
      case 'process-ecredit-requests':
        result = await processEcreditRequests();
        break;
      default:
        return NextResponse.json(
          { success: false, message: `Unknown task: ${task}` },
          { status: 400 }
        );
    }
    
    return NextResponse.json({
      success: true,
      task,
      result
    });
  } catch (error) {
    console.error('Error executing scheduled task:', error);
    return NextResponse.json(
      { success: false, message: 'Failed to execute scheduled task' },
      { status: 500 }
    );
  }
}

// Check prices for all active flights
async function checkPrices() {
  try {
    // Call the check-prices API endpoint
    const response = await fetch(new URL('/api/cron/check-prices', process.env.NEXT_PUBLIC_BASE_URL).toString(), {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });
    
    if (!response.ok) {
      throw new Error(`Failed to check prices: ${response.status} ${response.statusText}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error('Error checking prices:', error);
    throw error;
  }
}

// Process pending ecredit requests
async function processEcreditRequests() {
  try {
    // Call the process-ecredit-requests API endpoint
    const response = await fetch(new URL('/api/cron/process-ecredit-requests', process.env.NEXT_PUBLIC_BASE_URL).toString(), {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });
    
    if (!response.ok) {
      throw new Error(`Failed to process ecredit requests: ${response.status} ${response.statusText}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error('Error processing ecredit requests:', error);
    throw error;
  }
}
